rSDK
====
**Deprecated** in favor of EDIF: https://github.com/ClickteamLLC/windows-edif

This was an SDK originally developed by James along with the other members of Aquadasoft (now split-up). It is heavily macro-based and does some pretty ugly things, but it was the best SDK for extension development before EDIF. Its use is not recommended unless of course you are maintaining an existing rSDK extension that cannot be ported to EDIF.
