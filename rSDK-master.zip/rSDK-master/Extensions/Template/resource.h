//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ext.rc
//
#define IDST_OBJNAME                    128
#define IDST_AUTHOR                     129
#define IDST_COPYRIGHT                  130
#define IDST_COMMENT                    131
#define IDST_HTTP                       132
#define TEST                            133
#define MN_ACTIONS                      20000
#define MN_CONDITIONS                   20001
#define MN_EXPRESSIONS                  20002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
