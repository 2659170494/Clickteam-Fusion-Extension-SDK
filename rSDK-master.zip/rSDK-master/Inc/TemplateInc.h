// Include guard
#ifndef TEMPLATE_INC
#define TEMPLATE_INC

// General oddness prevents this from being defined sometimes
#ifndef COXSDK
#define	COXSDK
#endif

// Include some of the header files which shouldn't be modified- this file should be used as a precompiled header
#include	"ccxhdr.h"
#include	"Surface.h"

#endif // !TEMPLATE_INC