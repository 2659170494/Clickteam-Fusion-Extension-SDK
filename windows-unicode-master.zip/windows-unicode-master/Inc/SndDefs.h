
#ifndef SndDefs_h
#define SndDefs_h

#define SNDMGR_API __declspec(dllimport)

#endif // SndDefs_h
