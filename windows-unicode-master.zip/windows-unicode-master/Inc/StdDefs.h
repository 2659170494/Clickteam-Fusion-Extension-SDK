
#ifndef StdDefs_h
#define StdDefs_h

#define STDDLL_API __declspec(dllimport)

#endif // StdDefs_h
