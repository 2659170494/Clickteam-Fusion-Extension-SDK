
#ifndef ImgFltDefs_h
#define ImgFltDefs_h

#define IMGFLTMGR_API __declspec(dllimport)

#endif // ImgFltDefs_h

