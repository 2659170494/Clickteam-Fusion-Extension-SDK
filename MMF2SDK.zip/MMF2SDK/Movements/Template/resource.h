//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MvtExt.rc
//
#define IDI_ICON1                       101
#define IDS_MVT1NAME                    1000
#define IDS_MVT1_MOVEATSTART            1001
#define IDS_MVT_MOVEATSTART             1001
#define IDS_MVT1_MOVEATSTART_INFO       1002
#define IDS_MVT_MOVEATSTART_INFO        1002
#define IDS_MVT1_BOUNCE                 1003
#define IDS_MVT1_BOUNCE_INFO            1004
#define IDS_MVT1_SPEED                  1005
#define IDS_MVT_SPEED                   1005
#define IDS_MVT1_SPEED_INFO             1006
#define IDS_MVT_SPEED_INFO              1006
#define IDS_MVT1_SEGMENTSIZE            1007
#define IDS_MVT_NOFSEGMENTS             1007
#define IDS_MVT1_SEGMENTSIZE_INFO       1008
#define IDS_MVT_NOFSEGMENTS_INFO        1008
#define IDS_INITDIR                     1009
#define IDS_INITDIR_INFO                1010
#define IDS_MVT2NAME                    1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
