
#ifndef SurfaceDefs_h
#define SurfaceDefs_h

#define SURFACES_API __declspec(dllimport)

#endif // SurfaceDefs_h
