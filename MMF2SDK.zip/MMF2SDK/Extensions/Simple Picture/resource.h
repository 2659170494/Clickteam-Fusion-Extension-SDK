//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ext.rc
//
#define IDST_OBJNAME                    128
#define IDST_AUTHOR                     129
#define IDST_COPYRIGHT                  130
#define IDST_COMMENT                    131
#define IDST_HTTP                       132
#define IDS_SETTEXT_TITLE               133
#define M_ACT_SETTEXT                   200
#define M_ACT_LOADFILE                  200
#define M_EXP_GETTEXT                   201
#define M_EXP_GETFILENAME               201
#define IDS_PROP_FILENAME               400
#define IDS_PROP_FILENAME_INFO          401
#define IDS_PROP_TRANSPCOLORGROUP       402
#define IDS_PROP_TRANSPCOLORGROUP_INFO  403
#define IDS_PROP_TRANSPFIRSTPIXEL       404
#define IDS_PROP_TRANSPFIRSTPIXEL_INFO  405
#define IDS_PROP_TRANSPCOLORCUSTOM      406
#define IDS_PROP_TRANSPCOLORCUSTOM_INFO 407
#define IDS_FILENAME                    408
#define M_ACTION                        5000
#define M_ACT_P1                        5501
#define M_ACT_P2                        5502
#define M_CONDITION                     6000
#define M_CND_P1                        6501
#define M_CND_P2                        6502
#define M_CND_P3                        6503
#define M_EXPRESSION                    7000
#define M_EXPRESSION2                   7001
#define M_EXPRESSION3                   7002
#define M_EXP_P1                        7500
#define M_EXP_P2                        7501
#define MN_ACTIONS                      20000
#define MN_CONDITIONS                   20001
#define MN_EXPRESSIONS                  20002
#define DB_SETUP                        20003
#define ID_HELP                         20004
#define IDMN_ACTION                     25000
#define IDMN_ACT_SETTEXT                25000
#define IDMN_ACT_LOADFILE               25000
#define IDMN_CONDITION                  26000
#define IDMN_EXPRESSION                 27000
#define IDMN_EXPRESSION2                27001
#define IDMN_EXP_GETTEXT                27001
#define IDMN_EXP_GETFILENAME            27001
#define IDMN_EXPRESSION3                27002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
