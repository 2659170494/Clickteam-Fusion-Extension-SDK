//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ext.rc
//
#define IDST_OBJNAME                    128
#define IDST_AUTHOR                     129
#define IDST_COPYRIGHT                  130
#define IDST_COMMENT                    131
#define IDST_HTTP                       132
#define IDS_SETTEXT_TITLE               133
#define IDS_SETINT_TITLE                134
#define IDS_SETFLOAT_TITLE              135
#define M_ACT_SETTEXT                   200
#define M_EXP_GETTEXT                   201
#define M_ACT_SETINT                    202
#define M_ACT_SETFLOAT                  203
#define M_EXP_GETINT                    204
#define M_EXP_GETFLOAT                  205
#define M_CND_ISEMPTY                   206
#define M_CND_CHANGED                   207
#define IDS_PROP_TEXT                   400
#define IDS_PROP_TEXT_INFO              401
#define IDS_PROP_BACKCOLOR              402
#define IDS_PROP_BACKCOLOR_INFO         403
#define IDS_PROP_SYSTEMCOLORS           404
#define IDS_PROP_SYSTEMCOLORS_INFO      405
#define IDS_PROP_BORDER                 406
#define IDS_PROP_BORDER_INFO            407
#define MN_ACTIONS                      20000
#define MN_CONDITIONS                   20001
#define MN_EXPRESSIONS                  20002
#define IDMN_ACTION                     25000
#define IDMN_ACT_SETTEXT                25000
#define IDMN_ACT_SETINT                 25001
#define IDMN_ACT_SETFLOAT               25002
#define IDMN_CONDITION                  26000
#define IDMN_CND_ISEMPTY                26000
#define IDMN_CND_HASCHANGED             26001
#define IDMN_CND_CHANGED                26001
#define IDMN_EXPRESSION                 27000
#define IDMN_EXP_GETTEXT                27001
#define IDMN_EXP_GETINT                 27002
#define IDMN_EXP_GETFLOAT               27003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
