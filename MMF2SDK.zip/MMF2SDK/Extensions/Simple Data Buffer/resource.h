//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ext.rc
//
#define IDST_OBJNAME                    128
#define IDST_AUTHOR                     129
#define IDST_COPYRIGHT                  130
#define IDST_COMMENT                    131
#define IDST_HTTP                       132
#define M_ACT_SETAT                     200
#define M_EXP_GETAT                     201
#define M_EXP_GETSIZE                   202
#define IDS_SETAT_OFFSET                203
#define IDS_SETAT_VALUE                 204
#define IDS_GETAT_OFFSET                205
#define M_ACT_LOADFILE                  206
#define M_ACT_SAVEFILE                  207
#define M_EXP_GETFILENAME               208
#define IDS_PROP_FILENAME               209
#define IDS_PROP_FILENAME_INFO          210
#define IDS_ALLFILESFILTER              211
#define IDS_PROP_TEXT                   400
#define IDS_PROP_TEXT_INFO              401
#define MN_ACTIONS                      20000
#define MN_CONDITIONS                   20001
#define MN_EXPRESSIONS                  20002
#define ID_HELP                         20004
#define IDMN_ACTION                     25000
#define IDMN_ACT_SETAT                  25000
#define IDMN_ACT_LOADFILE               25001
#define IDMN_ACT_SAVEFILE               25002
#define IDMN_CONDITION                  26000
#define IDMN_EXPRESSION                 27000
#define IDMN_EXP_GETAT                  27000
#define IDMN_EXP_GETSIZE                27001
#define IDMN_EXP_GETFILENAME            27002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
